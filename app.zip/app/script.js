function authenticateUser() {
    var username = document.getElementById("username").value;
    var password = document.getElementById("password").value;

    // Simple authentication logic (replace with your actual authentication logic)
    if (username === "your_username" && password === "your_password") {
        alert("Login successful!");
        window.location.href = "home.html"; // Redirect to the home page
    } else {
        alert("Login failed. Please check your username and password.");
    }
}
